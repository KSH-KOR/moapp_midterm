enum FilterOption {
  nokidszone,
  petfriendly,
  freebreakfast,
}