
const homepageRoute = '/';
const loginRoute = '/login';
const signupRoute = '/signup';
const detailRoute = '/detail';
const favoritedHotelRoute = '/favorite';
const myPageRoute = '/my-page';
const searchRoute = '/search';