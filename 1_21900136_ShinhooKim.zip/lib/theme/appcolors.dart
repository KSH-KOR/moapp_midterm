import 'package:flutter/material.dart';

class AppColors{
  static const buttonBackgroundColor = Color.fromARGB(255, 207, 207, 207);
  static const toggleButtonBGRColor = Colors.blue;
}